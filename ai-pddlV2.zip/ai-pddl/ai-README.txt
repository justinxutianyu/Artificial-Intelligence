---- PDDL part -----
We have 4 pddl files which are two domain files and two problem files each for ghost and pacman.


In the pacman domain file, we define 4 acitons and a rule.The rule is that if a super pacman eats a ghost, he will become unsuper. In the pacman domain file，each aciton will take two parameters.  
The first action is moving to a normal location. At that normal location, there will be no ghost, no food and no capsule. 
The second action is moving to eat the food. In this action, the pacman will move to eat the food next to him. 
The third action is moving to eat the capusle. In this move, when the pacman meet a capsule on its way to eat food,the pacman will eat the capsule.Then his statement will be eating capsule which means the pacman will become super and can eat the ghost.
The forth action is moving to eat the ghost. This action happens when the pacman is super and on his way to food.If there is a ghost, the pacman will eat the ghost and become unsuper.


In the pacman problem file, we define an inital grid that looks like the following graph. * means walls, F means food, P means pacman, G means ghost, C means capsule, H means this location is home for pacman.

 -------------------------------------
 |  H  |  H  |  H  |     |     |  P  |
 -------------------------------------
 |  H  |  H  |  H  *     |     |  C  |
 -------*****-------------*****-------
 |  H  *  H  |  H  |  G  |     *  G  |
 -------------------------------------
 |  H  |  H  |  H  |     |     |  F  |
 -------*****-------------*****-------
 |  H  *  H  |  H  *  F  |     *     |
 -*****-------------------------*****-
 |  H  |  H  |  H  |     |     |     |
 -------------------------------------

The goal state is to eat all the food and go back to the home area location. 
We use our pacman-domain pddl file to solve the problem of our pacman-problem pddl file and get a plan.
The steps show below:

Found Plan (output)
(move l05 l04)
(move l04 l03)
(move l03 l02)
(move l02 l12)
(move l12 l22)
(move l22 l32)
(move l32 l42)
(move l42 l32)
(move l32 l33)
(move l33 l34)
(move_to_eat_food l34 l35)
(move l35 l34)
(move l34 l33)
(move_to_eat_food l33 l43)
(move l43 l53)
(move l53 l54)
(move_to_eat_food l54 l55)
(move l55 l54)
(move l54 l53)
(move l53 l52)
(reach-goal)

According to this plan, we can see that first the pacman eats the capsule,then it becomes super.Second,it eats the ghost and become unsuper. Third,it eats the food that is nearest to it. Finally, it eats all other foods and goes back to the home location.



In the ghost doamin file, we define 3 actions and a rule.The rule is that if a ghost moves to a super pacman, it will return to the home location and meanwhile the pacman will become unsuper.
The first action is moving to a normal location. At that location, there will be no pacman. 
The second action is moving to eat pacman. In this action, the ghost will eat the unsuper pacman next to him. 
The third action is moving to super Pacman. In this action, the ghost will move to the location which has a super pacman, and then the ghost will be eaten by that super pacmam and go back to the inital place which is the home location.Meanwhile,the super pacman will become unsuper.

In the ghost problem file, we define an inital grid that looks like the following graph.
H means this location is home location for ghost. SP means super pacman. G means ghost.

-------------------------------
 | SP  |     *     |     |     |
 -------------------------------
 |     |     | SP  |     *     |
 -------*****-------------------
 |     *     |     |     | SP  |
 -------------------*****-*****-
 |     *     |     *     |     |
 -*****-------------------------
 |     |     |     |     |(H)G |
 -------------------------------

 The goal state for the ghost is to eat all the pacman.
 We use our ghost-domain pddl file to solve the problem defined in ghost-problem pddl file,then get a plan.
 The steps show below:

(move l44 l43)
(move l43 l42)
(move l42 l32)
(move l32 l31)
(move l31 l30)
(move l30 l20)
(move l20 l10)
(move_to_eat_superpacman l10 l00 l44)
(move l44 l43)
(move l43 l42)
(move l42 l32)
(move l32 l22)
(move_to_eat_pacman l22 l12)
(move l12 l13)
(move l13 l23)
(move_to_eat_pacman l23 l24)
(move l24 l23)
(move l23 l22)
(move l22 l12)
(move l12 l11)
(move l11 l10)
(move_to_eat_pacman l10 l00)

 According to the plan, we can see that the ghost first move to the nearest super pacman and then the ghost go back to home location, meanwhile the pacman become unsuper. Next, the ghost eats all the unsuper pacmans.



