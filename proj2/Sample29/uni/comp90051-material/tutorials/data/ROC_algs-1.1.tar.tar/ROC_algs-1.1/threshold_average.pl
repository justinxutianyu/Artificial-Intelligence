#!/usr/local/bin/perl -w
#
#    threshold_average.pl --- Average a set of ROC curves by threshold
#    Copyright (2002-2006) by Tom Fawcett
#    Created Tue Jul  2 2002 by Tom Fawcett (tfawcett at acm dot org)
#    $Id: threshold_average.pl,v 1.2 2006/06/02 17:55:16 fawcett Exp fawcett $
#
#

=head1 NAME

threshold_average.pl -- Average a set of ROC curves by sampling FP rates

=head1 SYNOPSIS

    perl threshold_average.pl  [options] ROC1 ROC2 ...

 Options:
   --samples N      Specify the number of samples to take
   --selection S    Specify the sample selection strategy
   --confidence C   The confidence level for the confidence interval
   --help           Short synposis
   --man            Longer help

=head1 DESCRIPTION

This script averages a set of ROCs by threshold.  Each argument B<ROC>i is a
file containing a ROC curve.  It should contain lines like: S<FP TP THRESHOLD>


Outputs lines of:
S<X Y DX DY>

DX and DY specify the confidence interval corresponding to the confidence C.

=head1 OPTIONS

=over 8

=item B<--samples N>
=item B<--sample_points N>

N is the number of samples to take.  Default is 10.  See the --selection
option for details on what this actually does.

Note that this will actually yield N+2 total ROC points: N points from the ROC
curves plus the extrema (0,0) and (1,1).

=item B<--selection> FREQUENCY|RANGE

Specify the threshold selection technique.  If FREQUENCY is chosen, the scores
are placed into N bins such that each bin has approximately the same number of
scores (ie, equal frequency).  Thresholds are chosen to separate the bins.  If
RANGE is chosen, the range of scores is divided into N pieces and the
thresholds are chosen that separate the pieces.

Default is RANGE.  Note that the algorithm described in the paper performs
I<frequency> based selection.

When a --samples N argument is supplied, divides the threshold range up into N
samples.  If N is greater than number of samples when FREQUENCY selection is
chosen (see below), uses all of them.  If RANGE selection is chosen, divides
the range into N intervals, regardless of whether this makes much sense.

=item B<--confidence> C

The specifies the confidence level for the confidence interval of the points
output.  Default is 95%


=item B<-help>

Print a brief help message and exits.

=item B<-man>

Prints the manual page and exits.

=back

=head1 AUTHOR AND BUG RECIPIENT

Tom Fawcett (tfawcett at acm dot org).

=head1 SEE ALSO

Tom Fawcett (2003). "ROC Graphs: Notes and Practical Considerations for
Researchers", HP Labs Tech Report HPL-2003-4.  Available from:
http://www.purl.org/net/tfawcett/papers/ROC101.pdf

=cut

##### REQUIREMENTS  ##########################################################
use English;
use strict;
use POSIX qw(HUGE_VAL);
use Pod::Usage;
use Statistics::Descriptive;               # For mean and standard deviations
use Statistics::Distributions "tdistr";    # For the T distribution
use Getopt::Long;

use constant DEBUG => 0;

use constant INFINITY     => HUGE_VAL;
use constant NEG_INFINITY => -(HUGE_VAL);
use constant EPSILON      => 0.000001;

# simple structure constants
use constant FPrate => 0;
use constant TPrate => 1;
use constant SCORE  => 2;

##### PROCESS ARGUMENTS  #####################################################
#  Sample has two meanings here.
#  Statistically (and for computing the degrees of freedom) it refers
#  to the number of ROC curves we're sampling from.
#  Threshold samples are the number of sampled threshold points.
my $N_THRESH_SAMPLES = 10;
my $CONFIDENCE       = 0.95;
my $HELP             = 0;
my $MAN              = 0;
my $SELECTION        = "RANGE";

GetOptions( "samples|sample_points=i" => \$N_THRESH_SAMPLES,
	    "selection=s"             => \$SELECTION,
	    "confidence=f"            => \$CONFIDENCE,
	    "help|?"                  => \$HELP,
	    "man"                     => \$MAN
	  )
  or pod2usage( -verbose => 1 );

if ($HELP) { pod2usage( -verbose => 1 ) }
if ($MAN)  { pod2usage( -verbose => 2 ) }

my $N_ROCS = @ARGV;
if ( $N_ROCS < 2 )
{
    print "Need at least two ROC curves to average\n";
    pod2usage( -verbose => 1 );
}

if ( $CONFIDENCE < 0.5 or $CONFIDENCE > 1 )
{
    print "CONFIDENCE should be between 0.5 and 1.0\n";
    pod2usage( -verbose => 1 );
}

$SELECTION = uc($SELECTION);
if ( $SELECTION ne "RANGE" and $SELECTION ne "FREQUENCY" )
{
    die "SELECTION must be either RANGE or FREQUENCY\n";
}

if ( defined($N_THRESH_SAMPLES) and $N_THRESH_SAMPLES <= 1 )
{
    print "You probably want more than one sample point\n";
    pod2usage( -verbose => 1 );
}

#  Used in the confidence() function at end.
my $TWO_TAILED_ERROR = 1 - $CONFIDENCE;
my $ONE_TAILED_ERROR = $TWO_TAILED_ERROR / 2;

##############################################################################
my $DF = $N_ROCS - 1;    # Degrees of freedom for t test

my (@average_points);
my (@ROCS);
my (%score);
my (@all_scores);

for my $ROC_file (@ARGV)
{
    my (@ROC);

    open( ROC, $ROC_file ) or die "open($ROC_file): $!";

    while (<ROC>)
    {
	s/\#.*//;    # kill comments
	next if /^\s*$/;               # skip blanks
	redo if s/\s*\\\s*\n$/<>/e;    # fold \
	s/^\s+//;                      # kill prefix whitespace
	s/\s+$//;                      # and suffix whitespace

	chomp;
	my ( $x, $y, $score ) = split(/[\s,]+/);

	unless (     defined($x)
		 and defined($y)
		 and defined($score)
		 and $score ne "" )
	{
	    die "Ill-formed ROC line at line $INPUT_LINE_NUMBER: $_";
	}
	if ( $score eq "inf" )  { $score = INFINITY; }
	if ( $score eq "-inf" ) { $score = NEG_INFINITY; }

	push( @ROC, [ $x, $y, $score ] );

	$score{$score} = 1;
    }
    close(ROC);

    #  Sort ROC points decreasing by score
    @ROC = sort { $b->[SCORE] <=> $a->[SCORE] } @ROC;

    push( @ROCS, [@ROC] );
}

#  This next bit is convoluted because hashes can't handle infinity -- they
#  use the string representation ("inf") which screws up numerical sorting.
#  Make global scores unique and sort them decreasing.
delete $score{"inf"};
delete $score{"-inf"};
@all_scores = sort { $b <=> $a } ( keys %score );

my (@thresh_samples) = generate_threshold_samples(@all_scores);

@thresh_samples = sort { $b <=> $a } @thresh_samples;

if (DEBUG)
{
    describe_threshold_partitions( \@all_scores, \@thresh_samples );
}

@thresh_samples = ( INFINITY, @thresh_samples, NEG_INFINITY );

if (DEBUG)
{
    print scalar(@thresh_samples), " threshold samples:\n",
      join( "\n", @thresh_samples ), "\n";
}

for my $thresh (@thresh_samples)
{

    my ($Xstats) = new Statistics::Descriptive::Sparse;
    my ($Ystats) = new Statistics::Descriptive::Sparse;

    print "Threshold: $thresh\n" if DEBUG;

    #  Peel down each ROC curve until the score is >= this threshold
    for my $i ( 0 .. $#ROCS )
    {
	while ( @{ $ROCS[$i] } > 1 and $ROCS[$i][0][SCORE] > $thresh )
	{
	    shift( @{ $ROCS[$i] } );
	}
	if (DEBUG)
	{
	    print "Sampling ROC curve $i\n";
	    print "\t@{$ROCS[$i][0]}\n";
	}
	$Xstats->add_data( $ROCS[$i][0][FPrate] );
	$Ystats->add_data( $ROCS[$i][0][TPrate] );
    }

    my ($Xmean)  = $Xstats->mean;
    my ($Xstdev) = $Xstats->standard_deviation;
    my ($Ymean)  = $Ystats->mean;
    my ($Ystdev) = $Ystats->standard_deviation;

    my ($Xdelta) = confidence_interval( $Xmean, $N_ROCS, $Xstdev );
    my ($Ydelta) = confidence_interval( $Ymean, $N_ROCS, $Ystdev );

    print join( " ", $Xmean, $Ymean, $Xdelta, $Ydelta ), "\n";

}

exit;

#  Returns confidence delta.
sub confidence_interval
{
    my ( $mean, $N, $stdev ) = @_;
    my ($DF) = $N;
    my ($a)  = tdistr( $DF, $ONE_TAILED_ERROR );
    my ($c)  = $a * $stdev / sqrt($N);
    return $c;
}

sub array_min_max
{
    my $min = INFINITY;
    my $max = NEG_INFINITY;
    for (@_)
    {
	$min = $_ if $_ < $min;
	$max = $_ if $_ > $max;
    }
    return ( $min, $max );
}

sub generate_threshold_samples
{
    my (@scores) = @_;

    if ( $SELECTION eq "RANGE" )
    {
	my ( $min, $max ) = array_min_max(@all_scores);
	$max = $max + 0;
	my $range = $max - $min;
	my $incr  = $range / ( $N_THRESH_SAMPLES + 1 );

	my $start = $min + $incr;
	print "t=$start to $max by $incr\n" if DEBUG;

	for ( my $t = $start ; $t < ( $max - EPSILON ) ; $t += $incr )
	{
	    push( @thresh_samples, $t );
	}

    }
    else
    {    # SELECTION == FREQUENCY
	my $incr = @all_scores / ( $N_THRESH_SAMPLES + 1 );
	$incr = 1 if $incr < 1;
	if (DEBUG)
	{
	    print "incr = ", @all_scores + 0, " / ", ( $N_THRESH_SAMPLES + 1 ),
	      " = $incr\n";
	}

	my ($i);
	for ( $i = $incr ; $i < $#all_scores ; $i += $incr )
	{
	    push( @thresh_samples, $all_scores[$i] + EPSILON );
	}
    }

    return (@thresh_samples);
}

sub describe_threshold_partitions
{
    my (@scores)  = @{ $_[0] };
    my (@samples) = @{ $_[1] };

    print "SCORES: @scores\n";
    print "SAMPLES: @samples\n";

    my $smpidx = 0;
    my $scidx  = 0;
    my(@gtscores) = ();

    while ($scidx <= $#scores and $smpidx <= $#samples) {
	if ( $scores[$scidx] < $samples[$smpidx] ) {
	    print "Sample $samples[$smpidx]: ", @gtscores+0, " (",
		join(", ", @gtscores), ")\n";
	    if (@gtscores == 0) {
		print "*** Warning, sample includes no points!\n";
	    }
	    @gtscores = ( $scores[$scidx] );
	    $scidx++;
	    $smpidx++;
	} else {
	    push(@gtscores, $scores[$scidx]);
	    $scidx++;
	}
    }
    print "Sample -inf: ", @gtscores+0, " (",
		join(", ", @gtscores), ")\n";
}

##### End of threshold_average.pl
