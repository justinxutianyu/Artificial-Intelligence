#!/usr/local/bin/perl -w
#
#    ROC --- Compute ROC curve and/or AUC of a set of scored instances.
#    Created Thu Jun  9 2005 by Tom Fawcett (<tfawcett@acm.org>)
my $Copyright = "Copyright (2006) Tom Fawcett";
#    $Id: ROC.pl,v 1.3 2006/08/15 19:51:46 fawcett Exp fawcett $
#
#
=head1 NAME

ROC.pl - Generate an ROC curve from a set of scored instances

=head1 SYNOPSIS

ROC.pl [options]  instance_file positive_class

 Options:
   --input-format   Set the input format of the instances
   --AUC            Print the area under the ROC curve (AUC)
   --ROC            Output the ROC curve points
   --unscaled       Produce a PN graph instead of an ROC graph
   --scores         Include scores with output
   --convex	    Compute convex hull of ROC
   --quiet          Suppress extraneous output
   --help           Short synposis
   --man            Longer help

=head1 OPTIONS

=over 8

=item B<--INPUT-FORMAT>

Determines what the input file fields should look like.  Values are:

=over 8

=item WEKA (default): Each line is:

	Instno, Real_class, Score, Predicted_class
This is the format printed by Weka with the -p argument.

=item PRIE:  Used by PRIE.  Each line is:

	Real_class, Predicted_class, Score

=back

=item B<--AUC>

Binary switch (default: ON).  Output the area under the ROC curve.

=item B<--ROC>

Binary switch (default: ON).  Output the ROC points into the file
ROC.B<positive_class>.  Each point will be an (X,Y) pair separated by a space.
Output will include score as a third field if --scores is specfied.


=item B<--unscaled>

Binary switch (default: OFF).  Compute the unscaled version of the ROC and
AUC points.  This essentially generates the PN graph (0:N,0:P) instead of
the ROC graph (0:1,0:1).

=item B<--convex>

Binary switch (default: OFF).  Compute the convex hull of the ROC points,
instead of the raw points.

=item B<-help>

Print a brief help message and exits.

=item B<-man>

Prints the manual page and exits.

=back

=head1 DESCRIPTION

Computes the ROC curve(s) of the points in instance_file.  B<positive_class> is
the class that should be considered positive, for the sake of the ROC curve.
It makes no difference to the AUC.

=cut
##### REQUIREMENTS  ##########################################################
use English;
use strict;
use Getopt::Long;
use Pod::Usage;

use constant DEBUG => 0;

use constant INFINITY => 1e1000;

print "ROC.pl $Copyright\n";

##### PROCESS ARGUMENTS  #####################################################
my($INPUT_FORMAT)  = "WEKA";
my($QUIET)	   = 0;
my $PRODUCE_AUC	   = 1;
my $PRODUCE_ROC	   = 1;
my $INCLUDE_SCORES  = 0;
my $HELP           = 0;
my $MAN            = 0;
my $UNSCALED       = 0;
my $CONVEX         = 0;

GetOptions(
	   "input_format=s"   => \$INPUT_FORMAT,
	   "quiet"	      => \$QUIET,
	   "AUC!"	      => \$PRODUCE_AUC,
	   "ROC!"	      => \$PRODUCE_ROC,
	   "unscaled!"        => \$UNSCALED,
	   "convex!"          => \$CONVEX,
	   "scores!"          => \$INCLUDE_SCORES,
	   "help|?"	      => \$HELP,
	   "man"	      => \$MAN
	  )
    or pod2usage(2);

pod2usage(-verbose => 1)                if $HELP;
pod2usage(-verbose => 2)                if $MAN;

my($instance_file, $pos_class) = @ARGV;

#  Check values of arguments
if (!(defined($instance_file) and defined($pos_class))) {
    pod2usage("Insufficient arguments");
}
$INPUT_FORMAT = uc($INPUT_FORMAT);
if ($INPUT_FORMAT ne "WEKA" and $INPUT_FORMAT ne "PRIE") {
    pod2usage("Unknown input_format: $INPUT_FORMAT");
}

##############################################################################
#  Global variables
my(@insts);
my(%inst_count);		# Number of instances of each class
my($neg_class);
##############################################################################

#  Read in the instances
open(INSTS, $instance_file) or die "open($instance_file): $!\n";

while (my $line = <INSTS>) {
    chomp($line);

    #  Split fields on whitespace or comma
    $line =~ s/^\s+//;		# Delete leading whitespace
    $line =~ s/\s+$//;		# Delete trailing whitespace
    my(@fields) = split(/[\s,]+/, $line);

    my($instno, $true_class, $score, $predicted_class);
    if ($INPUT_FORMAT eq "WEKA") {
	($instno, $true_class, $score, $predicted_class) = @fields;
    } else {
	($true_class, $predicted_class, $score)          = @fields;
    }
    push(@insts, [$true_class,$score] );
    $inst_count{$true_class}++;
}

close(INSTS);

##############################################################################
#  Some error checking before we begin
##############################################################################

my(@classes) = keys %inst_count;

if (@classes != 2) {
    die "Error, this script can only handle two classes, found: ",
	join(", ", @classes), "\n";
}

if ($pos_class eq $classes[0]) {
    $neg_class = $classes[1];
} elsif ($pos_class eq $classes[1]) {
    $neg_class = $classes[0];
} else {
    die "Error, found no examples of the positive class ($pos_class)\n"
}
my $P = $inst_count{$pos_class};
my $N = $inst_count{$neg_class};

if (!defined($P) or $P == 0) {
    die "Error, saw no examples of the positive class ($pos_class)\n"
} elsif (!defined($N) or $N == 0) {
    die "Error, saw no examples of the negative class ($neg_class)\n"
}
##############################################################################
unless ($QUIET) {
    print "ROC $pos_class vs $neg_class, P=$P, N=$N\n";
}

#  Sort instances decreasing by score
@insts = sort { $b->[1]  <=>  $a->[1] } @insts;

my($TP, $FP)		    = (0,0);
my(@ROC_points)	            = ([0, 0,'AllNeg']);
my($lastscore)		    = -1;
my($FPR, $TPR)		    = (0.0, 0.0);
my($old_FPR, $old_TPR)	    = (0,0);

#  This loop constructs the ROC curve, leaving it in @ROC_points.  The AUC
#  is calculated after the ROC points so that the area is still correct if
#  --CONVEX is specified.
for my $inst (@insts) {
    my($true_class, $score) = @$inst;
    if ($pos_class eq $true_class) {
	$TP++;
    } else {
	$FP++;
    }
    #  Update rates.  We know that $P != 0 and $N != 0.
    if ($UNSCALED) {
	$TPR = $TP;
	$FPR = $FP;
    } else {
	$TPR = $TP / $P;
	$FPR = $FP / $N;
    }

    #  This test ensures that we wait for the end of a span of
    #  equal score before emitting a point.
    if ($score != $lastscore) {
	#  Record this point
	my $latest = [$FPR,$TPR,$score];

	#  Now remove any introduced concavity if --CONVEX was specified
	if ($CONVEX) {
	    while (@ROC_points > 2) {
		print "Inside CONVEX, ROC:\n";
		print_ROC();
		my $tos		= $ROC_points[-1];
		my $tos_1	        = $ROC_points[-2];
		my $latest_slope    = slope($latest, $tos);
		my $previous_slope  = slope($tos, $tos_1);
		print "Latest slope = $latest_slope,  prev = $previous_slope\n";

		if ($latest_slope <= $previous_slope) {
		    last;
		} else {
		    pop(@ROC_points);
		    print "Discarded stack top, ROC:\n";
		    print_ROC();
		}
	    }
	}
	push(@ROC_points, $latest);
    }


    $old_FPR = $FPR;
    $old_TPR = $TPR;
    $lastscore = $score;
}

#  Done processing instances.
#  Connect ROC curve to (1,1) if we're not there yet
if ($old_FPR != 1 or $old_TPR != 1) {
    push(@ROC_points, [$FPR,$TPR]);
}

if ($PRODUCE_ROC) {
    &output_ROC_points($pos_class, $neg_class, @ROC_points)
}

if ($PRODUCE_AUC) {
    my $AUC = 0;

    for my $i (1 .. $#ROC_points) {
	my $last = $ROC_points[$i-1];
	my $this = $ROC_points[$i];
	my($last_FPR, $last_TPR) = @$last;
	my($this_FPR, $this_TPR) = @$this;

	#  Add in trapezoid area
	my($new_area) = trapezoid_area($last_FPR, $last_TPR, $this_FPR, $this_TPR);
	if (DEBUG) {
	    print "Adding in trap area ($last_FPR, $last_TPR, $this_FPR, $this_TPR)\n";
	}

	$AUC += $new_area;
    }

    print "AUC = $AUC\n";
}

exit;

sub output_ROC_points {
    my($P_class, $N_class, @points) = @_;
    my($outfile) = "ROC.${P_class}";
    open(OUT, ">$outfile") or die "open(>$outfile): $!";

    foreach my $pt (@points) {
	print OUT join(" ",
		       $pt->[0],
		       $pt->[1],
		       ($INCLUDE_SCORES ? () . $pt->[2] : "")),
			   "\n";
    }

    close(OUT);
}

#  This area assumes x1<=x2 and y1<=y2
#  This is simply base * 1/2 height.
sub trapezoid_area {
    my($x1, $y1, $x2, $y2) = @_;
    ( $x2 - $x1 ) *
      ( $y1 + ($y2 - $y1)/2.0 )
}

#  Returns slope between two ROC points
sub slope {
    my($pt1, $pt2) = @_;
    my($x1, $y1) = @$pt1;
    my($x2, $y2) = @$pt2;

    return ($x1 == $x2) ? INFINITY
	: ($y2 - $y1) / ($x2 - $x1);
}

sub print_ROC {
    my $i = 0;
    for my $pt (@ROC_points) {
	print "$i: @$pt\n";
	$i ++;
    }
}


##### End of ROC.pl
