#!/usr/local/bin/perl -w
#
# vertical_average.pl --- Average a set of ROC curves vertically (by FP rate)
# Copyright (2006) Tom Fawcett
# Created Tue Jul  2 2002 by Tom Fawcett (tfawcett at acm dot org)
# $Id: vertical_average.pl,v 1.1 2006/06/01 05:29:45 fawcett Exp $
#
=head1 NAME

vertical_average.pl -- Average a set of ROC curves by sampling FP rates

=head1 SYNOPSIS

vertical_average.pl [options]  files...

 Options:
   --increment F    Distance between FP (vertical) samples
   --stdev          Include standard deviation in output (third value)
   --help           Short synposis
   --man            Longer help

=head1 OPTIONS

=over 8

=item B<--increment>

Increment between vertical (FP) samples.  Default is 0.1, producing 11 samples
from 0 to 1.  Value should be >0 and <0.5.  Endpoints of 0 and 1 will always
be included regardless of the value of increment.

=item B<--stdev>

Include standard deviations in the output, as the third field.

=item B<-help>

Print a brief help message and exits.

=item B<-man>

Prints the manual page and exits.

=back

=head1 DESCRIPTION

Computes the vertical averages of a set of ROC curve.  Each file supplied on
the command line is assumed to contain the points of a single ROC curve in the
form of (FP,TP) pairs separated by a comma or whitespace.

The option B<increment> determines the increment of the X axis (FP rate)
samples.  Default is 0.1, giving 11 samples.

The output is a set of (FP,TP) pairs representing the average ROC curve.  If
B<stdev> is specified, the output is (FP,TP,stdev) representing the standard
error of the mean.

=cut
##### REQUIREMENTS  ##########################################################
use strict;
use English;
use Getopt::Long;
use Statistics::Descriptive;
use Pod::Usage;

##### PROCESS ARGUMENTS  #####################################################
#  Defaults
my $INCLUDE_STDEV  = 0;
my $HELP           = 0;
my $MAN            = 0;
my $FP_INCREMENT   = 0.1;

GetOptions("stdev!"	       => \$INCLUDE_STDEV,
	   "increment=f"       => \$FP_INCREMENT,
	   "help|?"	       => \$HELP,
	   "man"	       => \$MAN
	  )
    or pod2usage(-verbose => 1);

pod2usage(-verbose => 1)                if $HELP;
pod2usage(-verbose => 2)                if $MAN;

if ($FP_INCREMENT <= 0 or $FP_INCREMENT > .5) {
    pod2usage("increment should be >0 and <0.5")
}

if (@ARGV == 0) {
    pod2usage("You must supply at least one ROC curve (file) to average!");
} elsif (@ARGV == 1 and $INCLUDE_STDEV) {
    pod2usage("You must supply at least two ROC curves (files) to get a stdev");
}

##############################################################################
my(@files);
my(%TP, %FPs);

for my $file (@ARGV) {
   open(IN, $file) or die "open($file): $!\n";
   push(@files, $file);

   while (<IN>) {
      chomp;
      s/^\s+//;
      my($FP, $TP) = split(/[\s+,]+/);
      next unless defined($FP);
      #  Set the TP for this FP, but only if we don't yet have a value for it,
      #  or if this TP value is greater than what we already have.
      if (!defined($TP{$file}{$FP}) or $TP{$file}{$FP} < $TP) {
	 $TP{$file}{$FP} = $TP;
      }
   }
   close(IN);

   #  Force brackets
   $TP{$file}{0} = 0 unless defined($TP{$file}{0});
   $TP{$file}{1} = 1 unless defined($TP{$file}{1});
   #  Store ordered list of FPs
   $FPs{$file} = [ sort { $a <=> $b } keys %{$TP{$file}} ];

}


#####  Average the points
#  Should really use binary (instead of linear) search here, but for
#  reasonable increments the overhead is too high.

my($FP_desired);
for ($FP_desired=0 ; $FP_desired <= 1 ; $FP_desired += $FP_INCREMENT) {

    my($TPs) = Statistics::Descriptive::Full->new();

  FILE: for my $file (@files) {
	my(@FPs) = @{$FPs{$file}};
	#  Get (FP,TP) pair for this FP_desired.
	#  Match may be exact, or we may have to interpolate

	my($FP1) = 0;
	for my $FP2 (@FPs) {

	    if ($FP2 == $FP_desired) {
		#  Found exact match
		$TPs->add_data($TP{$file}{$FP_desired});
		next FILE;

	    } elsif ($FP_desired < $FP2) {
		#  Found bracket -- interpolate between FP1 and FP2
		my($TP1)  = $TP{$file}{$FP1};
		my($TP2)  = $TP{$file}{$FP2};
		my($Dx)	  = $FP2 - $FP1;
		my($Dy)	  = $TP2 - $TP1;
		if ($Dx == 0) {	# Avoid divide by zero
		    die "Vertical slope at $file $FP2\n";
		}
		my($m)    = $Dy / $Dx;
		my($TP_result) = $TP1 + $m * ($FP_desired - $FP1);
		$TPs->add_data($TP_result);
		next FILE;
	    }
	    $FP1 = $FP2;
	}
	die "No FP found in $file for $FP_desired";
    }

    #  All points assembled
    print join("\t", $FP_desired, $TPs->mean());
    if ($INCLUDE_STDEV) {
	###  What we really want is the stderr of the mean, which is the
	###  stdev of the means with an additional sqrt(N) in the denominator.
	my($stderr_of_mean) =
	    $TPs->standard_deviation() * sqrt(1 / $TPs->count);
	print "\t", $stderr_of_mean;
    }
    print "\n";

}

##### End of vertical_average.pl
