#!/usr/local/bin/perl -w
#  This is a very basic test script for the tests in the subdirectories.
##### REQUIREMENTS
use English;
use strict;
use POSIX "tmpnam";
use Getopt::Long;

my $keep_files = 0;
my $DEBUG      = 0;

GetOptions("keep-files" => \$keep_files,
	   "debug"      => \$DEBUG
	  );

for my $testfile (@ARGV) {
    my $cmd;
    my $stdout_file;
    my @files_to_clean;
    my $test_failed = 0;

    open(TEST, $testfile)  or die("open($testfile): $!\n");

  OUTER:
    while (<TEST>) {

	if (/^#/) {
	    next;

	} elsif (/^\[file (.*?)\]/) {
	    my $filename = $1;
	    open(OUT, ">$filename");
	    while (<TEST>) {
		if (/^\[/) {
		    close(OUT);
		    print "Created file $filename\n" if $DEBUG;
		    push(@files_to_clean, $filename);
		    redo OUTER;
		} else {
		    print OUT;
		}
	    }
	    close(OUT);
	    print "??? Created $filename at EOF -- why?\n";

	} elsif (/^\[cmd\]/) {
	    $cmd = <TEST>;
	    chomp($cmd);
	    $stdout_file = tmpnam();
	    push(@files_to_clean, $stdout_file);
	    print "Running command: $cmd\n" if $DEBUG;
	    print "Output captured to: $stdout_file\n" if $DEBUG;

	    if (system("$cmd > $stdout_file")) {
		print "cmd $cmd returned an error:\n";
		system("cat $stdout_file");
		$test_failed = 1;
		last OUTER;
	    }

	} elsif (/\[(expect|include) (.*?)\]/) {
	    my $keyword = $1;
	    my $filename = $2;

	    my $redo_it = 0;
	    my @test_against;
	    while (<TEST>) {
		chomp;
		if (/^\[/) {
		    $redo_it = 1;
		    last;
		} else {
		    push(@test_against, $_);
		}
	    }

	    if ($filename eq "output") {
		$filename = $stdout_file;
	    }
	    push(@files_to_clean, $filename);

	    my(@file_lines) = `cat $filename`;
	    chomp(@file_lines);

	    print "Comparing to output file: $filename\n" if $DEBUG;

	    my $oidx = 0;
	    my $cidx = 0;
	    while ($cidx <= $#test_against and $oidx <= $#file_lines) {
		if ($keyword eq "expect") {
		    if ($file_lines[$oidx] !~ m/^$test_against[$cidx]\s*/) {
			print "Output $filename differs from expected at line $oidx\n";
			print "Expected:\n|$test_against[$cidx]|\n";
			print "Saw:\n|$file_lines[$oidx]|\n";
			$test_failed = 1;
			last OUTER;
		    }
		    $cidx++;
		} else {
		    if ($file_lines[$oidx] eq $test_against[$cidx]) {
			print "Saw expected line $test_against[$cidx]\n" if $DEBUG;
			$cidx++;
		    }
		}
		$oidx ++;

	    }

	    if ($cidx <= $#test_against) {
		print "Error, never saw:\n";
		print join("\n", @test_against[$cidx .. $#test_against]);
		$test_failed = 1;
		last OUTER;

	    } elsif ($oidx <= $#file_lines and $keyword eq "expect") {
		print "Seeing extraneous output:\n";
		print join("\n", @file_lines[$oidx .. $#file_lines]);
		$test_failed = 1;
		last OUTER;

	    } else {
		print "Test passed\n" if $DEBUG;
	    }
	    redo OUTER if $redo_it;

	} elsif (/^\[end\]i/) {
	    last;
	}
    }

    close(TEST);

    #  We're done with this test, clean up and see if we succeeded.

    unless ($test_failed or $keep_files) {
	for my $file (@files_to_clean) {
	    unlink($file);
	}
    }

    if ($test_failed) {
	print "*** Test $testfile FAILS\n";

    } else {
	print "Test $testfile PASSES\n";
    }

}

##### End of test.pl
