# script : workshop02-sol.R
# author : Ben Rubinstein
# about  : Solutions to workshop 2, UniMelb COMP90051 Sem 2, 2015

# 1. Bayesian Posterior Updates
modelUpdate <- function(p, x)
  c(mean=(p["sd"] * p["sd"] * x + p["mean"]) / (p["sd"] * p["sd"] + 1),
    sd=sqrt((p["sd"] * p["sd"]) / (p["sd"] * p["sd"] + 1)))

train <- function(prior, samples) {
  models <- matrix(prior, nrow=2, ncol=1)
  rownames(models) <- names(prior)
  for (x in samples) {
    models <- cbind(models, modelUpdate(models[,ncol(models)], x))
  }
  models
}

reality <- c(mean=0)
sampleReality <- function(n) rnorm(n, mean=reality["mean"], sd=1) # samples i.i.d. from underlying process
modelPrior <- c(mean=0, sd=1)  # represent params of prior. TRY CHANGING THIS FOR Q1.3!!!
n <- 200
trainData <- sampleReality(n)
models <- train(modelPrior, trainData)

# Visualising just the model's parameters
plot(0, 0, xlim=c(0, n), ylim=range(models), xlab="Sample size", ylab="Current model", main="Evolution of Posterior", type="n")
lines(0:n, models["mean",], col="blue")
lines(0:n, models["sd", ], col="red")
lines(c(0, n), rep(reality["mean"], 2), lty="dashed")
legend(n, max(models), c("Posterior mean", "Posterior sd", "Actual mean"), col=c("blue", "red", "black"), lty=c("solid", "solid", "dashed"), xjust=1)

# Visualising the posterior density
xs <- seq(from=-3, to=3, length=100)
ylim <- c(0, 2)
plot(xs, xs, ylim=ylim, xlab="mu", ylab="P(mu|data so far)", main="Evolution of Posterior", type="n")
cols <- heat.colors(ncol(models))
for (i in 1:ncol(models)) {
  lines(xs, sapply(xs, dnorm, models["mean", i], models["sd", i]), col=cols[i])
}
points(reality["mean"], 0, pch=20, cex=2)
# As we expect, our best guess for the unknown mean closes in; and our confidence increases

# 2. Linear Approaches
# Linear regression of orange tree growth data
m <- lm(circumference ~ age, Orange)
xlim <- c(0, max(Orange[,"age"]))
ylim <- c(0, max(Orange[,"circumference"]))
plot(Orange[,"age"], Orange[,"circumference"], xlab="Age (days)", ylab="Circumference (mm)", main="Orange tree growth - Linear Regression", pch=20, xlim=xlim, ylim=ylim)
lines(xlim, predict(m, data.frame(age=xlim)), col="red", lty="dashed")
mse <- mean((Orange[,"circumference"] - predict(m, data.frame(age=Orange[,"age"])))^2)
text(xlim[1], ylim[2], paste("MSE:", mse), pos=4)

# Logistic regression classifying Ripley synth 2D data
library(MASS)  # includes the synth.tr data
m <- glm(yc ~ xs + ys, synth.tr, family="binomial")
plot(synth.tr[,"xs"], synth.tr[,"ys"], pch=c(1,19)[synth.tr[,"yc"]+1], col=c("blue","red")[round(m$fitted.values)+1], xlab="x", ylab="y", main="Ripley 2D Synthetic Data - Logistic Regression")
xlim <- range(synth.tr[,"xs"])
ylim <- range(synth.tr[,"ys"])
lines(xlim, (m$coefficients["(Intercept)"] + m$coefficients["xs"] * xlim) / -m$coefficients["ys"])
acc <- mean(round(m$fitted.values) == synth.tr[,"yc"])
text(xlim[1], ylim[2], paste("Accuracy:", acc), pos=4)
