import math
import matplotlib.pyplot as plt
import numpy as np

"""
Python solutions to COMP90051 Week 2 workshop questions on Bayesian Statistics

Note: code only tested in Python 2.7... if it doesn't work in Python 3, it
shouldn't be hard to fix

Author: Andrew Bennett
Data: August, 2015
"""

# parameters that can be edited
NUM_SAMPLES = 200
ACTUAL_VARIANCE = 1.0
ACTUAL_MEAN = 0.0

MU_INITIAL_MEAN = 0.0
MU_INITIAL_STDDEV = 1.0

def update_mean_stddev(a, b, x):
    """
    updates mean and stddev of mu

    :param a: previous mean of mu
    :param b: previous stddev of mu
    :param x: observed data value from gaussian(mu, 1) distribution

    :return: tuple containing new mean and new stddev
        i.e. (a_new, b_new)
    """
    a_new = (b*b*x + a) / (b*b + 1)
    b_new = math.sqrt((b*b) / (b*b + 1))
    return a_new, b_new

def main():
    # generate samples from gaussian distribution
    gaussian_samples = np.random.normal(ACTUAL_MEAN, ACTUAL_VARIANCE,
                                        NUM_SAMPLES)

    # generate successive beliefs of mean and std-dev for distribution of mu
    mu_mean_beliefs = [0] * (NUM_SAMPLES + 1)
    mu_stddev_beliefs = [0] * (NUM_SAMPLES + 1)
    mu_mean_beliefs[0] = MU_INITIAL_MEAN
    mu_stddev_beliefs[0] = MU_INITIAL_STDDEV
    for i in range(NUM_SAMPLES):
        a_new, b_new = update_mean_stddev(mu_mean_beliefs[i],
                                          mu_stddev_beliefs[i],
                                          gaussian_samples[i])
        mu_mean_beliefs[i+1] = a_new
        mu_stddev_beliefs[i+1] = b_new

    # plot results
    plt.figure()
    plt.plot(list(range(NUM_SAMPLES+1)), mu_mean_beliefs,
             'r-', label="mean")
    plt.plot(list(range(NUM_SAMPLES+1)), mu_stddev_beliefs,
             'b-', label="stddev")
    plt.plot([ACTUAL_MEAN] * (NUM_SAMPLES + 1), 'k--', label="actual mean")
    plt.plot()
    plt.title("Convergence of mean / stddev of mu")
    plt.xlabel("Iteration")
    plt.ylabel("Parameter Values")
    plt.ylim(-1.0, 1.0)
    plt.legend()

    plt.show()

if __name__ == "__main__":
    main()