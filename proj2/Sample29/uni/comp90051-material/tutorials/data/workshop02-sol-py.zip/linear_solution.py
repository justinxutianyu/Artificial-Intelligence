import csv
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.metrics import accuracy_score

"""
Python solutions to COMP90051 Week 2 workshop questions on Linear Models

Note: code only tested in Python 2.7... if it doesn't work in Python 3, it
shouldn't be hard to fix

Author: Andrew Bennett
Data: August, 2015
"""

# paths to data files (edit if necessary):
ORANGE_DATA_PATH = "orange.csv"
SYNTH_TR_DATA_PATH = "synth-tr.csv"


def main_linreg():
    """
    linear regression code
    (edit ORANGE_DATA_PATH to correct path if necessary)
    """

    # read in orange data into list of dictionaries
    fp = open(ORANGE_DATA_PATH)
    orange_data = list(csv.DictReader(fp))
    fp.close()

    # obtain x / y values to fit model to (note: x is list of lists)
    x = [[float(row["age"])] for row in orange_data]
    y = [float(row["circumference"]) for row in orange_data]

    # fit linear model Y ~ X using standard linear regression
    regression_model = linear_model.LinearRegression()
    regression_model.fit(x, y)

    # create linear plot from predicted y values over this range (sort x first)
    x_test = sorted(x)
    y_test = regression_model.predict(x_test)

    # plot results
    plt.figure()
    plt.plot(x, y, 'ro', label="data")
    plt.plot(x_test, y_test, 'b-', linewidth=3,
             label="line of best fit")
    plt.title("linear model for tree age vs circumference")
    plt.xlabel("age")
    plt.ylabel("circumference")
    # plt.legend()

def main_logreg():
    """
    logistic regression code
    (edit SYNTH_TR_DATA_PATH to correct path if necessary)
    """

    # read in synth-tr data into list of dictionaries
    fp = open(SYNTH_TR_DATA_PATH)
    synth_tr_data = list(csv.DictReader(fp))
    fp.close()

    # obtain features / labels to fit model to
    feature_vectors = [[float(row["xs"]), float(row["ys"])]
                       for row in synth_tr_data]
    labels = [int(row["yc"])
              for row in synth_tr_data]
    num_vectors = len(feature_vectors)

    # fit logistic regression classification model to data
    # (y are labels, x are featuers)
    logreg_model = linear_model.LogisticRegression()
    logreg_model.fit(feature_vectors, labels)

    # calculate accuracy on trained data (note: this is biased!)
    predicted_labels = logreg_model.predict(feature_vectors)
    accuracy = accuracy_score(labels, predicted_labels)

    # get logistic regression fitted parameters
    x_weight, y_weight, bias = logreg_model.raw_coef_[0]

    # create lists of points for plotting decision boundary
    # boundary equation is:  x_weight * x + y_weight * y + bias = 0
    # equivalent to:  y = - (x_weight / y_weight) * x - (bias / y_weight)
    x_dec_boundary = sorted([vec[0] for vec in feature_vectors])
    y_dec_boundary = [-(x_weight/y_weight) * x - bias/y_weight
                      for x in x_dec_boundary]

    # plot logistic regression results
    plt.figure()
    # plot positive examples red
    positive_examples = [feature_vectors[i] for i in range(num_vectors)
                         if labels[i] == 1]
    x_pos = [vec[0] for vec in positive_examples]
    y_pos = [vec[1] for vec in positive_examples]
    plt.plot(x_pos, y_pos, 'ro', label="data")
    # plot negative examples blue
    negative_examples = [feature_vectors[i] for i in range(num_vectors)
                         if labels[i] == 0]
    x_neg = [vec[0] for vec in negative_examples]
    y_neg = [vec[1] for vec in negative_examples]
    plt.plot(x_neg, y_neg, 'bo', label="data")
    plt.plot(x_dec_boundary, y_dec_boundary, 'k-', linewidth=3,
             label="decision boundary")
    plt.title("decision boundary form logistic regression (acc = %.2f)"
              % accuracy)
    plt.xlabel("x")
    plt.ylabel("y")
    # plt.legend()


if __name__ == "__main__":
    main_linreg()
    main_logreg()

    # finally show all plots
    plt.show()
